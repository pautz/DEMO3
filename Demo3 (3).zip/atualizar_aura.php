<?php
session_start();
if (!isset($_SESSION["loggedin_odonto2"]) || $_SESSION["loggedin_odonto2"] !== true) {
    header("location: ../farolqr/site/login_farolqr.php");
    exit;
}

$conn = new mysqli("localhost", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
$conn->set_charset("utf8mb4");

$usuarioSessao = $_SESSION["username_odonto2"];

// Busca saldo_total do usuário
$stmt = $conn->prepare("SELECT saldo_total FROM identificacao_odonto2 WHERE username = ?");
$stmt->bind_param("s", $usuarioSessao);
$stmt->execute();
$result = $stmt->get_result();
$dados = $result->fetch_assoc();
$stmt->close();

if ($dados) {
    $saldoTotal = intval($dados['saldo_total']);

    // Atualiza saldo_aura das máquinas do usuário
    $stmtUpdate = $conn->prepare("UPDATE maquinas SET saldo_aura = ? WHERE usuario = ?");
    $stmtUpdate->bind_param("is", $saldoTotal, $usuarioSessao);
    $stmtUpdate->execute();
    $stmtUpdate->close();

    echo "<p style='color:green;'>✅ Saldo de aura atualizado para $saldoTotal em todas as máquinas do usuário $usuarioSessao.</p>";
    echo "<p><a href='index.php'>⬅️ Voltar ao Menu</a></p>";
} else {
    echo "<p style='color:red;'>⚠️ Usuário não encontrado em identificacao_odonto2.</p>";
}
?>
