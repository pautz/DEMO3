<?php
session_start();
if (!isset($_SESSION["loggedin_odonto2"]) || $_SESSION["loggedin_odonto2"] !== true) {
    header("location: ../farolqr/site/login_farolqr.php");
    exit;
}

$conn = new mysqli("localhost", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
$conn->set_charset("utf8mb4");

$usuarioSessao = $_SESSION["username_odonto2"];

if (isset($_GET['rfid_tag'])) {
    $tag = $_GET['rfid_tag'];

    // Busca máquina vinculada à tag
    $stmt = $conn->prepare("SELECT maquina_id, maquina_nome, ultimo_status FROM rfid_tags WHERE tag_code = ?");
    $stmt->bind_param("s", $tag);
    $stmt->execute();
    $dados = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($dados) {
        $id = intval($dados['maquina_id']);
        $nome = $dados['maquina_nome'];
        $ultimoStatus = intval($dados['ultimo_status']);

        // Alterna status
        $novoStatus = ($ultimoStatus == 1) ? 0 : 1;

        // Atualiza status da máquina
        $stmtUp = $conn->prepare("UPDATE maquinas SET status = ? WHERE id = ? AND usuario = ?");
        $stmtUp->bind_param("iis", $novoStatus, $id, $usuarioSessao);
        $stmtUp->execute();
        $stmtUp->close();

        // Atualiza último_status da tag
        $stmtTag = $conn->prepare("UPDATE rfid_tags SET ultimo_status = ? WHERE tag_code = ?");
        $stmtTag->bind_param("is", $novoStatus, $tag);
        $stmtTag->execute();
        $stmtTag->close();

        // Salva histórico
        if ($novoStatus == 1) {
            $stmtHist = $conn->prepare("INSERT INTO historico_status (maquina_id, status_novo, usuario, inicio_gasto) VALUES (?, 1, ?, NOW())");
            $stmtHist->bind_param("is", $id, $usuarioSessao);
            $stmtHist->execute();
            $stmtHist->close();
            echo "<p style='color:green;'>Máquina $id ($nome) ativada pela tag $tag.</p>";
        } else {
            $stmtBusca = $conn->prepare("SELECT inicio_gasto FROM historico_status WHERE maquina_id = ? AND status_novo = 1 ORDER BY id DESC LIMIT 1");
            $stmtBusca->bind_param("i", $id);
            $stmtBusca->execute();
            $inicio = $stmtBusca->get_result()->fetch_assoc()['inicio_gasto'] ?? null;
            $stmtBusca->close();

            if ($inicio) {
                $horas = (strtotime(date("Y-m-d H:i:s")) - strtotime($inicio)) / 3600;
                $stmtHist = $conn->prepare("INSERT INTO historico_status (maquina_id, status_novo, usuario, fim_gasto, total_gasto) VALUES (?, 0, ?, NOW(), ?)");
                $totalGasto = round($horas * 1.0, 2); // supondo 1 aura = R$1
                $stmtHist->bind_param("isd", $id, $usuarioSessao, $totalGasto);
                $stmtHist->execute();
                $stmtHist->close();
            }
            echo "<p style='color:red;'>Máquina $id ($nome) desativada pela tag $tag.</p>";
        }
    } else {
        echo "<p style='color:red;'>Tag RFID não cadastrada.</p>";
    }
}
?>
