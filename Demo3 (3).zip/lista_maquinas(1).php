<?php
session_start();

date_default_timezone_set('America/Cuiaba'); // Ajuste de fuso horário

$conn = new mysqli("localhost", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
$conn->set_charset("utf8mb4");

require_once __DIR__ . "/../site/phpqrcode/qrlib.php";

$usuarioSessao = $_SESSION["username_odonto2"];

// ---------------- FUNÇÃO ÚNICA PARA ALTERAR STATUS E SALVAR HISTÓRICO ----------------
function alternarStatusESalvarHistorico(mysqli $conn, int $id, int $status, string $usuarioSessao, ?string $lat, ?string $lng): bool {
    $stmtCheck = $conn->prepare("SELECT usuario, nome, auras_por_hora, saldo_aura FROM maquinas WHERE id = ?");
    $stmtCheck->bind_param("i", $id);
    $stmtCheck->execute();
    $m = $stmtCheck->get_result()->fetch_assoc();
    $stmtCheck->close();

    if (!$m) { echo "<p style='color:red;'>Máquina não encontrada.</p>"; return false; }

    $usuarioMaquina = $m['usuario'] ?? null;
    $consumoHora = floatval($m['auras_por_hora'] ?? 0);
    $saldo = floatval($m['saldo_aura'] ?? 0);

    if ($usuarioMaquina !== $usuarioSessao) {
        echo "<p style='color:red;'>Usuário da sessão não é dono da máquina.</p>";
        return false;
    }

    if ($status === 1 && $saldo < $consumoHora) {
        echo "<p style='color:red;'>Saldo insuficiente para ativar.</p>";
        return false;
    }

    if ($lat !== null && $lng !== null) {
        $stmtUp = $conn->prepare("UPDATE maquinas SET status = ?, latitude = ?, longitude = ? WHERE id = ? AND usuario = ?");
        $stmtUp->bind_param("issis", $status, $lat, $lng, $id, $usuarioSessao);
    } else {
        $stmtUp = $conn->prepare("UPDATE maquinas SET status = ? WHERE id = ? AND usuario = ?");
        $stmtUp->bind_param("iis", $status, $id, $usuarioSessao);
    }
    $stmtUp->execute();
    $stmtUp->close();

    if ($status === 1) {
        $stmtHist = $conn->prepare("INSERT INTO historico_status (maquina_id, status_novo, latitude, longitude, usuario, inicio_gasto) VALUES (?, 1, ?, ?, ?, NOW())");
        $lat2 = $lat ?? ''; $lng2 = $lng ?? '';
        $stmtHist->bind_param("isss", $id, $lat2, $lng2, $usuarioSessao);
        $stmtHist->execute();
        $stmtHist->close();
    } else {
        $stmtBusca = $conn->prepare("SELECT inicio_gasto FROM historico_status WHERE maquina_id = ? AND status_novo = 1 ORDER BY id DESC LIMIT 1");
        $stmtBusca->bind_param("i", $id);
        $stmtBusca->execute();
        $inicio = $stmtBusca->get_result()->fetch_assoc()['inicio_gasto'] ?? null;
        $stmtBusca->close();

        if ($inicio) {
            $horas = (strtotime(date("Y-m-d H:i:s")) - strtotime($inicio)) / 3600;
            if ($horas < 0) $horas = 0;
            $totalGasto = round($horas * $consumoHora, 2);

         $stmtSaldo = $conn->prepare("UPDATE maquinas SET saldo_aura = saldo_aura - ? WHERE usuario = ?");
$stmtSaldo->bind_param("ds", $totalGasto, $usuarioSessao);
$stmtSaldo->execute();
$stmtSaldo->close();

            $stmtHist = $conn->prepare("INSERT INTO historico_status (maquina_id, status_novo, latitude, longitude, usuario, fim_gasto, total_gasto) VALUES (?, 0, ?, ?, ?, NOW(), ?)");
            $lat2 = $lat ?? ''; $lng2 = $lng ?? '';
            $stmtHist->bind_param("isssd", $id, $lat2, $lng2, $usuarioSessao, $totalGasto);
            $stmtHist->execute();
            $stmtHist->close();
        }
    }
    return true;
}

// ---------------- POST (botões) ----------------
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"], $_POST["status"], $_POST["nome"])) {
    $id = intval($_POST["id"]);
    $status = intval($_POST["status"]);
    $lat = $_POST["lat"] ?? null;
    $lng = $_POST["lng"] ?? null;
    $nome = $_POST["nome"];

    $stmtN = $conn->prepare("SELECT usuario, nome FROM maquinas WHERE id = ?");
    $stmtN->bind_param("i", $id);
    $stmtN->execute();
    $rowN = $stmtN->get_result()->fetch_assoc();
    $stmtN->close();

    if ($rowN && $rowN['usuario'] === $usuarioSessao && $rowN['nome'] === $nome) {
        alternarStatusESalvarHistorico($conn, $id, $status, $usuarioSessao, $lat, $lng);
    } else {
        echo "<p style='color:red;'>Permissão negada ou nome não confere.</p>";
    }
}

// ---------------- GET (links/QR Codes) ----------------
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id"], $_GET["status"], $_GET["nome"])) {
    $id = intval($_GET["id"]);
    $status = intval($_GET["status"]);
    $nome = $_GET["nome"];

    $stmtN = $conn->prepare("SELECT usuario, nome FROM maquinas WHERE id = ?");
    $stmtN->bind_param("i", $id);
    $stmtN->execute();
    $rowN = $stmtN->get_result()->fetch_assoc();
    $stmtN->close();

    if ($rowN && $rowN['usuario'] === $usuarioSessao && $rowN['nome'] === $nome) {
        alternarStatusESalvarHistorico($conn, $id, $status, $usuarioSessao, null, null);
    } else {
        echo "<p style='color:red;'>Permissão negada ou nome não confere.</p>";
    }
}

// ---------------- FILTRO + PAGINAÇÃO ----------------
$filtroId = isset($_GET['filtroId']) ? intval($_GET['filtroId']) : null;
$filtroNome = isset($_GET['filtroNome']) ? trim($_GET['filtroNome']) : null;

$registrosPorPagina = 10;
$paginaAtual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$offset = ($paginaAtual - 1) * $registrosPorPagina;

if ($filtroId) {
    $stmt = $conn->prepare("SELECT id, nome, latitude, longitude, status, foto_url, usuario, auras_por_hora, saldo_aura FROM maquinas WHERE id = ? AND usuario = ? LIMIT ?, ?");
    $stmt->bind_param("isii", $filtroId, $usuarioSessao, $offset, $registrosPorPagina);
} elseif ($filtroNome) {
    $likeNome = "%".$filtroNome."%";
    $stmt = $conn->prepare("SELECT id, nome, latitude, longitude, status, foto_url, usuario, auras_por_hora, saldo_aura FROM maquinas WHERE nome LIKE ? AND usuario = ? ORDER BY id ASC LIMIT ?, ?");
    $stmt->bind_param("ssii", $likeNome, $usuarioSessao, $offset, $registrosPorPagina);
} else {
    $stmt = $conn->prepare("SELECT id, nome, latitude, longitude, status, foto_url, usuario, auras_por_hora, saldo_aura FROM maquinas WHERE usuario = ? ORDER BY id ASC LIMIT ?, ?");
    $stmt->bind_param("sii", $usuarioSessao, $offset, $registrosPorPagina);
}
$stmt->execute();
$result = $stmt->get_result();
$maquinas = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$totalRegistros = $conn->query("SELECT COUNT(*) as total FROM maquinas WHERE usuario = '".$conn->real_escape_string($usuarioSessao)."'")->fetch_assoc()['total'];
$totalPaginas = ceil($totalRegistros / $registrosPorPagina);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Lista de Máquinas</title>
<style>
    body { font-family: Arial; margin:20px; }
    table { width:100%; border-collapse:collapse; margin-top:20px; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
    th { background:#007BFF; color:#fff; }
    button { padding:6px 12px; border:none; border-radius:6px; cursor:pointer; }
    .ativa { background:green; color:#fff; }
    .inativa { background:red; color:#fff; }
    .paginacao { margin-top:20px; text-align:center; }
    .paginacao a { margin:0 5px; padding:8px 12px; background:#007BFF; color:#fff; text-decoration:none; border-radius:6px; }
    .paginacao a:hover { background:#0056b3; }
</style>
<script>
function atualizarStatus(id, nome, status){
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(pos){
            let lat = pos.coords.latitude.toFixed(6);
            let lng = pos.coords.longitude.toFixed(6);

            let form = document.createElement("form");
            form.method = "POST";
            form.action = "";

            ["id","nome","status","lat","lng"].forEach((name, idx) => {
                let input = document.createElement("input");
                input.type = "hidden"; 
                input.name = name;
                input.value = [id, nome, status, lat, lng][idx];
                form.appendChild(input);
            });

            document.body.appendChild(form);
            form.submit();
        }, function(error){
            alert("Não foi possível obter localização: " + error.message);
        });
    } else {
        alert("Geolocalização não suportada neste dispositivo.");
    }
}
</script>
</head>
<body>
<h1>Lista de Máquinas do Usuário <?= htmlspecialchars($usuarioSessao) ?></h1>

<form method="GET" action="">
    <input type="number" name="filtroId" placeholder="Filtrar por ID" value="<?= htmlspecialchars($filtroId ?? '') ?>">
    <input type="text" name="filtroNome" placeholder="Filtrar por Nome" value="<?= htmlspecialchars($filtroNome ?? '') ?>">
    <button type="submit">🔍 Buscar</button>
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Status</th>
        <th>Auras/Hora</th>
        <th>Saldo Aura Locada</th>
        <th>Foto</th>
        <th>QR Code</th>
        <th>Ação</th>
    </tr>
    <?php foreach($maquinas as $m): ?>
    <tr>
        <td><?= $m['id'] ?></td>
        <td><?= htmlspecialchars($m['nome']) ?></td>
        <td><?= $m['latitude'] ?></td>
        <td><?= $m['longitude'] ?></td>
        <td><?= $m['status'] == 1 ? "Ativa" : "Inativa" ?></td>
        <td><?= $m['auras_por_hora'] ?></td>
        <td><?= $m['saldo_aura'] ?></td>
        <td>
            <?php if (!empty($m['foto_url'])): ?>
                <img src="<?= htmlspecialchars($m['foto_url']) ?>" width="80" alt="Foto da máquina">
            <?php endif; ?>
        </td>
        <td>
            <?php 
            $dir = "qrcodes/";
            if (!is_dir($dir)) mkdir($dir);

            $arquivoAtivar = $dir . "maquina_" . $m['id'] . "_ativar.png";
            $urlAtivar = "https://carlitoslocacoes.com/Demo3/lista_maquinas.php?id=" . $m['id'] . "&nome=" . urlencode($m['nome']) . "&status=1";
            if (!file_exists($arquivoAtivar)) {
                QRcode::png($urlAtivar, $arquivoAtivar, QR_ECLEVEL_L, 5);
            }

            $arquivoDesativar = $dir . "maquina_" . $m['id'] . "_desativar.png";
            $urlDesativar = "https://carlitoslocacoes.com/Demo3/lista_maquinas.php?id=" . $m['id'] . "&nome=" . urlencode($m['nome']) . "&status=0";
            if (!file_exists($arquivoDesativar)) {
                QRcode::png($urlDesativar, $arquivoDesativar, QR_ECLEVEL_L, 5);
            }
            ?>
            <div style="display:flex; flex-direction:column; gap:8px; align-items:center;">
                <div>
                    <strong>Ativar</strong><br>
                    <img src="<?= htmlspecialchars($arquivoAtivar) ?>" width="120" alt="QR Code Ativar">
                </div>
                <div>
                    <strong>Desativar</strong><br>
                    <img src="<?= htmlspecialchars($arquivoDesativar) ?>" width="120" alt="QR Code Desativar">
                </div>
            </div>
        </td>
        <td>
            <?php if ($m['status'] == 1): ?>
                <button class="inativa" onclick="atualizarStatus(<?= $m['id'] ?>, '<?= htmlspecialchars($m['nome']) ?>', 0)">Desativar</button>
            <?php else: ?>
                <button class="ativa" onclick="atualizarStatus(<?= $m['id'] ?>, '<?= htmlspecialchars($m['nome']) ?>', 1)">Ativar</button>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<div class="paginacao">
    <?php for($i=1; $i <= $totalPaginas; $i++): ?>
        <a href="?pagina=<?= $i ?><?= $filtroId ? "&filtroId=$filtroId" : "" ?><?= $filtroNome ? "&filtroNome=$filtroNome" : "" ?>">
            <?= $i ?>
        </a>
    <?php endfor; ?>
</div>

</body>
</html>
