<?php
date_default_timezone_set('America/Cuiaba');

$conn = new mysqli("localhost", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
$conn->set_charset("utf8mb4");

require_once __DIR__ . "/../site/phpqrcode/qrlib.php";

function alternarStatusESalvarHistorico(mysqli $conn, int $id, int $status): bool {
    $stmtCheck = $conn->prepare("SELECT auras_por_hora, saldo_aura, status FROM maquinas WHERE id = ?");
    $stmtCheck->bind_param("i", $id);
    $stmtCheck->execute();
    $m = $stmtCheck->get_result()->fetch_assoc();
    $stmtCheck->close();

    if (!$m) { echo "<p style='color:red;'>Máquina $id não encontrada.</p>"; return false; }

    $consumoHora = floatval($m['auras_por_hora'] ?? 0);
    $saldo = floatval($m['saldo_aura'] ?? 0);
    $statusAtual = intval($m['status']);

    // Se for ligar ou manter ligada
    if ($status === 1) {
        if ($saldo < ($consumoHora / 60)) {
            echo "<p style='color:red;'>Saldo insuficiente para ativar máquina $id.</p>";
            return false;
        }

        if ($statusAtual === 0) {
            // Primeira ativação
            $stmtUp = $conn->prepare("UPDATE maquinas SET status = 1 WHERE id = ?");
            $stmtUp->bind_param("i", $id);
            $stmtUp->execute();
            $stmtUp->close();

            $stmtHist = $conn->prepare("INSERT INTO historico_status (maquina_id, status_novo, inicio_gasto) VALUES (?, 1, NOW())");
            $stmtHist->bind_param("i", $id);
            $stmtHist->execute();
            $stmtHist->close();

            echo "<p style='color:green;'>Máquina $id ligada.</p>";
        } else {
            // Já estava ligada → desconta parcial
            $stmtBusca = $conn->prepare("SELECT inicio_gasto FROM historico_status WHERE maquina_id=? AND status_novo=1 ORDER BY id DESC LIMIT 1");
            $stmtBusca->bind_param("i", $id);
            $stmtBusca->execute();
            $inicio = $stmtBusca->get_result()->fetch_assoc()['inicio_gasto'] ?? null;
            $stmtBusca->close();

            if ($inicio) {
                $horas = (strtotime(date("Y-m-d H:i:s")) - strtotime($inicio)) / 3600;
                if ($horas < 0) $horas = 0;
                $totalGasto = round($horas * $consumoHora, 4);

                $novoSaldo = $saldo - $totalGasto;
                if ($novoSaldo <= 0) {
                    // desliga automaticamente
                    $conn->query("UPDATE maquinas SET status=0, saldo_aura=0 WHERE id=$id");
                    $conn->query("INSERT INTO historico_status (maquina_id, status_novo, fim_gasto, total_gasto) VALUES ($id,0,NOW(),$saldo)");
                    echo "<p style='color:red;'>Máquina $id desligada por falta de saldo.</p>";
                } else {
                    // atualiza saldo e reinicia contador
                    $conn->query("UPDATE maquinas SET saldo_aura=$novoSaldo WHERE id=$id");
                    $conn->query("UPDATE historico_status SET inicio_gasto=NOW() WHERE maquina_id=$id AND status_novo=1 ORDER BY id DESC LIMIT 1");
                    echo "<p style='color:green;'>Máquina $id continua ligada. Saldo atualizado: $novoSaldo</p>";
                }
            }
        }
    }

    // Se for desligar manualmente
    if ($status === 0 && $statusAtual === 1) {
        $stmtBusca = $conn->prepare("SELECT inicio_gasto FROM historico_status WHERE maquina_id=? AND status_novo=1 ORDER BY id DESC LIMIT 1");
        $stmtBusca->bind_param("i", $id);
        $stmtBusca->execute();
        $inicio = $stmtBusca->get_result()->fetch_assoc()['inicio_gasto'] ?? null;
        $stmtBusca->close();

        if ($inicio) {
            $horas = (strtotime(date("Y-m-d H:i:s")) - strtotime($inicio)) / 3600;
            if ($horas < 0) $horas = 0;
            $totalGasto = round($horas * $consumoHora, 2);

            $stmtSaldo = $conn->prepare("UPDATE maquinas SET saldo_aura = saldo_aura - ? WHERE id = ?");
            $stmtSaldo->bind_param("di", $totalGasto, $id);
            $stmtSaldo->execute();
            $stmtSaldo->close();

            $stmtHist = $conn->prepare("INSERT INTO historico_status (maquina_id, status_novo, fim_gasto, total_gasto) VALUES (?, 0, NOW(), ?)");
            $stmtHist->bind_param("id", $id, $totalGasto);
            $stmtHist->execute();
            $stmtHist->close();
        }

        $stmtUp = $conn->prepare("UPDATE maquinas SET status=0 WHERE id=?");
        $stmtUp->bind_param("i", $id);
        $stmtUp->execute();
        $stmtUp->close();

        echo "<p style='color:blue;'>Máquina $id desligada.</p>";
    }

    return true;
}

// ---------------- GET ----------------
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id"], $_GET["status"], $_GET["tag"])) {
    $ids = explode(",", $_GET["id"]); // permite múltiplos IDs separados por vírgula
    $status = intval($_GET["status"]);
    $tagRecebida = trim($_GET["tag"]);

    foreach ($ids as $id) {
        $id = intval($id);

        // Busca a tag no banco (tabela rfid_tags)
        $stmtTag = $conn->prepare("SELECT tag_code FROM rfid_tags WHERE maquina_id = ?");
        $stmtTag->bind_param("i", $id);
        $stmtTag->execute();
        $tagBanco = $stmtTag->get_result()->fetch_assoc()['tag_code'] ?? null;
        $stmtTag->close();

        if ($tagRecebida === $tagBanco) {
            alternarStatusESalvarHistorico($conn, $id, $status);
        } else {
            echo "<p style='color:red;'>Tag inválida para máquina $id.</p>";
        }
    }
} else {
    echo "<p style='color:red;'>Parâmetros insuficientes.</p>";
}
?>
