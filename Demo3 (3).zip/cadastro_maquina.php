<?php
session_start();
if (!isset($_SESSION["loggedin_odonto2"]) || $_SESSION["loggedin_odonto2"] !== true) {
    header("location: ../farolqr/site/login_farolqr.php");
    exit;
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexão única (mesmo banco)
$conn = new mysqli("localhost", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
$conn->set_charset("utf8mb4");

$mensagem = "";

// Pega o próximo ID que será usado
$result = $conn->query("SHOW TABLE STATUS LIKE 'maquinas'");
$row = $result->fetch_assoc();
$proximoId = $row['Auto_increment'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $chave = trim($_POST["chave"]); // palavra-chave digitada
    $chaveCorreta = "TRATORCARLITO"; // defina sua chave secreta aqui

    if ($chave !== $chaveCorreta) {
        $mensagem = "❌ Palavra-chave inválida. Cadastro não autorizado.";
    } else {
        $nome = trim($_POST["nome"]);
        $latitude = trim($_POST["latitude"]);
        $longitude = trim($_POST["longitude"]);
        $status = intval($_POST["status"]);
        $aurasPorHora = intval($_POST["auras_por_hora"]);
        $usuario = $_SESSION["username_odonto2"];
        $fotoUrl = null;
        $rfidTag = trim($_POST["rfid_tag"]); // nova tag RFID

        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
            $nomeArquivo = 'maquina_' . uniqid() . '.' . $ext;
            $caminho = 'uploads/' . $nomeArquivo;
            if (!is_dir('uploads')) mkdir('uploads');
            move_uploaded_file($_FILES['foto']['tmp_name'], $caminho);
            $fotoUrl = $caminho;
        }

        // Inserir máquina
        $stmt = $conn->prepare("INSERT INTO maquinas 
            (nome, latitude, longitude, status, foto_url, usuario, auras_por_hora, criado_em) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssisssi", $nome, $latitude, $longitude, $status, $fotoUrl, $usuario, $aurasPorHora);
        $stmt->execute();
        $maquinaId = $stmt->insert_id;
        $stmt->close();

        // Inserir histórico inicial
        $stmtHist = $conn->prepare("INSERT INTO historico_status 
            (maquina_id, status_novo, latitude, longitude, usuario, criado_em) 
            VALUES (?, ?, ?, ?, ?, NOW())");
        $stmtHist->bind_param("iisss", $maquinaId, $status, $latitude, $longitude, $usuario);
        $stmtHist->execute();
        $stmtHist->close();

        // Inserir tag RFID no mesmo banco
        if (!empty($rfidTag)) {
            $stmtRFID = $conn->prepare("INSERT INTO rfid_tags 
                (tag_code, maquina_id, maquina_nome, usuario, ultimo_status, criado_em) 
                VALUES (?, ?, ?, ?, ?, NOW())");
            $stmtRFID->bind_param("sissi", $rfidTag, $maquinaId, $nome, $usuario, $status);
            $stmtRFID->execute();
            $stmtRFID->close();
        }

        $mensagem = "✅ Máquina cadastrada com sucesso! ID gerado: $maquinaId (Usuário: $usuario)";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Cadastro de Máquina</title>
<style>
    body { font-family: Arial; background:#eef; padding:20px; }
    .container { max-width:500px; margin:auto; background:#fff; padding:20px; border-radius:10px; }
    label { display:block; margin-top:10px; }
    input, select { width:100%; padding:8px; margin-top:5px; }
    button { margin-top:15px; padding:10px; background:#007BFF; color:#fff; border:none; border-radius:6px; cursor:pointer; }
    button:hover { background:#0056b3; }
    .id-preview { font-weight:bold; color:#007BFF; margin-bottom:15px; }
    .mensagem { padding:10px; background:#dff0d8; color:#3c763d; border-radius:6px; margin-bottom:15px; }
    img.preview { max-width:100%; margin-top:10px; border-radius:6px; }
</style>
<script>
function captarGPS(){
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(pos){
            document.getElementById("latitude").value = pos.coords.latitude.toFixed(6);
            document.getElementById("longitude").value = pos.coords.longitude.toFixed(6);
        }, function(error){
            alert("Erro ao captar localização: " + error.message);
        });
    } else {
        alert("Geolocalização não suportada neste dispositivo.");
    }
}

function previewFoto(event){
    let output = document.getElementById('preview');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.style.display = 'block';
}
</script>
</head>
<body>
<div class="container">
    <h2>Cadastro de Máquina</h2>
    <?php if($mensagem) echo "<div class='mensagem'>$mensagem</div>"; ?>
    <div class="id-preview">📌  ID provável: <?= $proximoId ?></div>
    <form method="POST" enctype="multipart/form-data">
        <label>Palavra-chave:</label>
        <input type="password" name="chave" required>

        <label>Sala/Nome da Máquina:</label>
        <input type="text" name="nome" required>
        <label>Latitude:</label>
        <input type="text" id="latitude" name="latitude" required>
        <label>Longitude:</label>
        <input type="text" id="longitude" name="longitude" required>
        <button type="button" onclick="captarGPS()">📍 Captar GPS</button>
        <label>Status:</label>
        <select name="status">
            <option value="0">Inativa</option>
            <option value="1">Ativa</option>
        </select>
        <label>Auras por hora:</label>
        <input type="number" name="auras_por_hora" min="0" required>
        <label>Foto:</label>
        <input type="file" name="foto" accept="image/*" onchange="previewFoto(event)">
        <img id="preview" class="preview" style="display:none;">
        
        <label>Tag RFID:</label>
        <input type="text" name="rfid_tag" required>

        <button type="submit">Cadastrar</button>
    </form>
</div>
</body>
</html>
