<?php
session_start();
if (!isset($_SESSION["loggedin_odonto2"]) || $_SESSION["loggedin_odonto2"] !== true) {
    header("location: ../farolqr/site/login_farolqr.php");
    exit;
}

$conn = new mysqli("localhost", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$usuarioSessao = $_SESSION["username_odonto2"];
$msg = "";

// ---------------- ATIVA/INATIVA AUTOMÁTICO VIA RFID ----------------
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["rfid_uid"])) {
    $rfid = trim($_POST["rfid_uid"]);

    // Buscar máquina vinculada ao RFID
    $stmt = $conn->prepare("SELECT id, nome, status FROM maquinas WHERE rfid_uid = ? AND usuario = ?");
    $stmt->bind_param("ss", $rfid, $usuarioSessao);
    $stmt->execute();
    $maquina = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$maquina) {
        $msg = "<p style='color:red;'>⚠️ Nenhuma máquina configurada para este RFID.</p>";
    } else {
        $id = intval($maquina['id']);
        $nome = $maquina['nome'];
        $statusAtual = intval($maquina['status']);
        $agora = date("Y-m-d H:i:s");

        if ($statusAtual == 0) {
            // Ativar
            $novoStatus = 1;
            $stmtUpdate = $conn->prepare("UPDATE maquinas SET status = ? WHERE id = ? AND usuario = ?");
            $stmtUpdate->bind_param("iis", $novoStatus, $id, $usuarioSessao);
            $stmtUpdate->execute();
            $stmtUpdate->close();

            $stmtHist = $conn->prepare("INSERT INTO historico_status 
                (maquina_id, status_novo, usuario, inicio_gasto) 
                VALUES (?, ?, ?, NOW())");
            $stmtHist->bind_param("iis", $id, $novoStatus, $usuarioSessao);
            $stmtHist->execute();
            $stmtHist->close();

            $msg = "<p style='color:green;'>✅ Máquina {$nome} (ID {$id}) ativada em {$agora} pelo RFID {$rfid}.</p>";
        } else {
            // Inativar
            $novoStatus = 0;
            $stmtUpdate = $conn->prepare("UPDATE maquinas SET status = ? WHERE id = ? AND usuario = ?");
            $stmtUpdate->bind_param("iis", $novoStatus, $id, $usuarioSessao);
            $stmtUpdate->execute();
            $stmtUpdate->close();

            $stmtHist = $conn->prepare("INSERT INTO historico_status 
                (maquina_id, status_novo, usuario, fim_gasto) 
                VALUES (?, ?, ?, NOW())");
            $stmtHist->bind_param("iis", $id, $novoStatus, $usuarioSessao);
            $stmtHist->execute();
            $stmtHist->close();

            $msg = "<p style='color:blue;'>ℹ️ Máquina {$nome} (ID {$id}) inativada em {$agora} pelo RFID {$rfid}.</p>";
        }
    }
}

// ---------------- LISTAGEM DE MÁQUINAS ----------------
$stmt = $conn->prepare("SELECT id, nome, rfid_uid, status, saldo_aura, auras_por_hora 
                        FROM maquinas WHERE usuario = ? ORDER BY id ASC");
$stmt->bind_param("s", $usuarioSessao);
$stmt->execute();
$result = $stmt->get_result();
$maquinas = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Controle Automático via RFID</title>
<style>
body { font-family: Arial, sans-serif; background:#f0f8ff; margin:0; padding:20px; }
h2 { color:#0077b6; }
table { width:100%; border-collapse:collapse; margin-top:20px; }
th, td { border:1px solid #ccc; padding:8px; text-align:center; }
th { background:#0077b6; color:#fff; }
</style>
</head>
<body>
    <h2>Controle Automático de Máquinas via RFID</h2>
    <?= $msg ?>

    <h3>Máquinas configuradas</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th><th>Nome</th><th>RFID UID</th><th>Status</th><th>Saldo Aura</th><th>Auras/Hora</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($maquinas as $m): ?>
            <tr>
                <td><?= htmlspecialchars($m['id']) ?></td>
                <td><?= htmlspecialchars($m['nome']) ?></td>
                <td><?= htmlspecialchars($m['rfid_uid']) ?></td>
                <td><?= $m['status'] == 1 ? "Ativa" : "Inativa" ?></td>
                <td><?= htmlspecialchars($m['saldo_aura']) ?></td>
                <td><?= htmlspecialchars($m['auras_por_hora']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
